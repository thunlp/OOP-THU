#ifndef __OPERATION__
#define __OPERATION__
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <vector>
#include "Variable.h"


class Operation {
	
	protected:

		int opPrior, opNum;
		std::string opType;
		std::vector<Variable*> varList;
		Variable res;

	public:

		~Operation() {
			varList.clear();
		}

		int getPrior() const {
			return opPrior;
		}

		int getOpNum() const {
			return opNum;
		}

		void setPrior(int tmp) {
			opPrior = tmp;
		}

		void setType(std::string type) {
			opType = type;
		}

		std::string getType() const {
			return opType;
		}

		bool priorCheck(const Operation& tmp) const{
			return (opPrior >= tmp.getPrior());
		}

		bool priorCheck(const Operation* tmp) const{
			return (opPrior >= tmp -> getPrior());
		}

		void addVar(Variable* var) {
			varList.push_back(var);
		}

		Variable getResult() const {
			return res;
		}

		virtual void operate() = 0;
};

class SetValueOp: public Operation{
	
	public:

		SetValueOp(std::string type) {
			opNum = 2;
			opPrior = 0;
			opType = type;
		}

		void operate() {
			Variable* v1 = varList[0];
			Variable* v2 = varList[1];
			v1 -> setValue(v2 -> getValue(), v2 -> getType());
			res = *v1;
		}
};

class PrintOp: public Operation{

	public:

		PrintOp(std::string type) {
			opNum = 1;
			opPrior = 0;
			opType = type;
		}

		void operate() {
			res = *(varList[0]);
			if (res.getType() == 1) 
				printf("%d\n", *(int*)(res.getValue()));
			else {
				if (*(bool*)(res.getValue())) printf("True\n"); else printf("False\n");
			}
		}

};

class OrOp: public Operation{

	public:

		OrOp(std::string type) {
			opNum = 2;
			opPrior = 1;
			opType = type;
		}

		void operate() {
			bool v1 = *(bool *)(varList[0] -> getValue());
			bool v2 = *(bool *)(varList[1] -> getValue());
			res = Variable(v1 || v2);
		}

};

class AndOp: public Operation{

	public:

		AndOp(std::string type) {
			opNum = 2;
			opPrior = 2;			
			opType = type;
		}

		void operate() {
			bool v1 = *(bool *)(varList[0] -> getValue());
			bool v2 = *(bool *)(varList[1] -> getValue());
			res = Variable(v1 && v2);
		}

};

class NotOp: public Operation{

	public:

		NotOp(std::string type) {
			opNum = 1;
			opPrior = 3;
			opType = type;
		}

		void operate() {
			bool v1 = *(bool *)(varList[0] -> getValue());
			res = Variable(!v1);
		}

};


class ComOp: public Operation {

	public: 

		ComOp(std::string type) {
			opNum = 2;
			opPrior = 4;
			opType = type;
		}

		void operate() {
			int v1 = *(int *)(varList[0] -> getValue());
			int v2 = *(int *)(varList[1] -> getValue());
			if (opType == ">") res = Variable(v1 > v2);
			if (opType == "<") res = Variable(v1 < v2);
			if (opType == "==") res = Variable(v1 == v2);
			if (opType == ">=") res = Variable(v1 >= v2);
			if (opType == "<=") res = Variable(v1 <= v2);
			if (opType == "!=") res = Variable(v1 != v2);			
		}
};

#endif