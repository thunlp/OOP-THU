#ifndef __VARIABLE__
#define __VARIABLE__
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <string>

class Variable {

	private:

		int type;
		void* value;
		std::string name;

		void clearValue() {
			if (type == 0) {
				bool* tmpValue = (bool*)(value);
				delete tmpValue;
			} else {
				int* tmpValue = (int*)(value);
				delete tmpValue;
			}
			value = NULL;
		}

		void changeValue(bool value) {
			type = 0;
			bool* tmpValue = new bool(value);
			this -> value = (void*)(tmpValue);
		}

		void changeValue(int value) {
			type = 1;
			int* tmpValue = new int(value);
			this -> value = (void*)(tmpValue);
		}

	public:

		Variable() {
			name = "";
			type = 0;
			value = NULL;
		}
		
		Variable(bool tmp) {
			name = "";
			changeValue(tmp);
		}

		Variable(int tmp) {
			name = "";
			changeValue(tmp);
		}

		Variable(std::string nam) {
			name = nam;
			type = 0;
			value = NULL;
		}
		
		Variable(std::string nam, bool tmp) {
			name = nam;
			changeValue(tmp);
		}

		Variable(std::string nam, int tmp) {
			name = nam;
			changeValue(tmp);
		}

		Variable(const Variable& tmp) {
			type = 0;
			value = NULL;
			name = tmp.name;
			if (tmp.value == NULL) return;
			if (tmp.type == 0) changeValue(*(bool*)(tmp.value)); else changeValue(*(int*)(tmp.value));
		}

		Variable& operator = (const Variable& tmp) {
			type = 0;
			value = NULL;
			name = tmp.name;
			if (tmp.value == NULL) return *this;
			if (tmp.type == 0) changeValue(*(bool*)(tmp.value)); else changeValue(*(int*)(tmp.value));
			return *this;
		}

		Variable(Variable&& tmp) {
			this -> value = tmp.value;
			this -> type = tmp.type;
			this -> name = tmp.name;
			tmp.value = NULL;
		}

		Variable& operator = (Variable&& tmp) {
			this -> value = tmp.value;
			this -> type = tmp.type;
			this -> name = tmp.name;
			tmp.value = NULL;
			return *this;
		}

		~Variable() {
			if (value != NULL) clearValue();
		}

		void setValue(bool tmp) {
			if (value != NULL) clearValue();
			changeValue(tmp);
		}

		void setValue(int tmp) {
			if (value != NULL) clearValue();
			changeValue(tmp);
		}

		void setType(int tmp) {
			type = tmp;
		}

		void setValue(void* tmp) {
			value = tmp;
		}

		void setValue(void* tmp, int typ) {
			if (value != NULL) clearValue();
			if (typ == 0) changeValue(*(bool*)(tmp)); else changeValue(*(int*)(tmp));
		}

		void* getValue() const {
			return value;
		}

		int getType() const {
			return type;
		}

		std::string getName() const {
			return name;
		}
};


#endif