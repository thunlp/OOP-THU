#include <cstring>
#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include "Variable.h"
#include "Operation.h"

std::map<std::string, Variable> variables;
std::vector<Variable> expVariables;
std::vector<Operation*> expOperations;
std::string expression;
std::string lastToken;

Variable& createVariable(std::string name) {
	if (variables.count(name) == 0) 
		variables[name] = Variable(name);
	return variables[name];
}

Variable getVariable(std::string name) {
	return variables[name];	
}

void addVariable(Variable con) {
	expVariables.push_back(con);
}

void addOperation(Operation* con) {
	while (expOperations.size() != 0 && (con == NULL || expOperations[expOperations.size() - 1] -> priorCheck(con))) {
		Operation* lastOp = expOperations[expOperations.size() - 1];
		for (int i = lastOp -> getOpNum(); i > 0; i--)
			lastOp -> addVar(&(expVariables[expVariables.size() - i]));
		lastOp -> operate();
		for (int i = lastOp -> getOpNum(); i > 0; i--)
			expVariables.pop_back();
		if (lastOp -> getType() == "=") {
			Variable res = lastOp -> getResult();
			variables[res.getName()] = res;
		} else {
			expVariables.push_back(lastOp -> getResult());
		}
		delete lastOp;
		expOperations.pop_back();
	}
	expOperations.push_back(con);
}

void addToken(std::string token) {
	if (token == "") {
		return;
	} else
	if (token == "#") {
		addOperation(NULL);
	} else
	if (token == "True") {
		addVariable(Variable(true));
	} else
	if (token == "False") {
		addVariable(Variable(false));
	} else 
	if (token == "and") {
		Operation* op = new AndOp(token);
		addOperation(op);
	} else
	if (token == "or") {
		Operation* op = new OrOp(token);
		addOperation(op);
	} else 
	if (token == "not") {
		Operation* op = new NotOp(token);
		addOperation(op);
	} else
	if (token == "=") {
		Operation* op = new SetValueOp(token);
		addOperation(op);
	} else
	if (token == "print") {
		Operation* op = new PrintOp(token);
		addOperation(op);
	} else
	if ('0' <= token[0] && token[0] <= '9') {
		addVariable(Variable(atoi(token.c_str())));
	} else
	if ('a' <= token[0] && token[0] <= 'z') {
		addVariable(createVariable(token));
	} else {
		Operation* op = new ComOp(token);
		addOperation(op);
	}
}

void clearExpression() {
	for (int i = 0; i < expOperations.size(); i++)
		if (expOperations[i] != NULL) delete expOperations[i];
	expOperations.clear();
	expVariables.clear();
}

void analyseExpression(std::string expression) {
	lastToken == "";
	expression = expression + " # ";
	for (int i = 0; i < expression.length(); i++)
		if (expression[i] != ' ') {
			lastToken += expression[i];
			continue;
		} else {
			addToken(lastToken);
			lastToken = "";
		}
}

int main(int argc, char** argv) {
	while (getline(std::cin, expression)) {
		analyseExpression(expression);
		clearExpression();
	}
	return 0;
}